package org.example.miniproject1.Exceptions.Credentials;

public class InvalidAgeException extends ValidationException {
    public InvalidAgeException(String message) {
        super(message);
    }
}