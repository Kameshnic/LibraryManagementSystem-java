package org.example.miniproject1.Exceptions.Credentials;

public class InvalidDateException extends ValidationException {
    public InvalidDateException(String message) {
        super(message);
    }
}
