package org.example.miniproject1.Exceptions.Credentials;

public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}