package org.example.miniproject1.Exceptions.AuthorException;

public class BookFileUploadException extends Exception {
    public BookFileUploadException(String message) {
        super(message);
    }
}