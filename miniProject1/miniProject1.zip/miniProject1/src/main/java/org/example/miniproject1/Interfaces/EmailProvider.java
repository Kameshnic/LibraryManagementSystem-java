package org.example.miniproject1.Interfaces;

public interface EmailProvider {
    String getEmail(); // Method to get the email address
}