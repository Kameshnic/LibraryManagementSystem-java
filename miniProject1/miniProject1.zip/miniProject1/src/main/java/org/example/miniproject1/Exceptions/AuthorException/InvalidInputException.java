package org.example.miniproject1.Exceptions.AuthorException;

public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}