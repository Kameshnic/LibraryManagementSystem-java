package org.example.miniproject1.Model;

public class KDTree {
    int k = 2;
    public Node insertRec(Node root, Location location, int depth) {
        if (root == null) {
            return new Node(location);
        }

        int cd = depth % k;
        double[] point = location.getCoordinates();
        double[] rootPoint = root.location.getCoordinates();

        if (point[cd] < rootPoint[cd]) {
            root.left = insertRec(root.left, location, depth + 1);
        } else {
            root.right = insertRec(root.right, location, depth + 1);
        }

        return root;
    }

    public Node insert(Node root, Location location) {
        return insertRec(root, location, 0);
    }


    private double squaredDistance(double[] point1, double[] point2) {
        return Math.pow(point1[0] - point2[0], 2) + Math.pow(point1[1] - point2[1], 2);
    }


    private void nearestNeighborSearch(Node root, double[] target, int depth, Node[] bestNode, double[] bestDist) {
        if (root == null) {
            return;
        }

        double dist = squaredDistance(root.location.getCoordinates(), target);
        if (dist < bestDist[0]) {
            bestDist[0] = dist;
            bestNode[0] = root;
        }

        int cd = depth % k;
        Node nextBranch = (target[cd] < root.location.getCoordinates()[cd]) ? root.left : root.right;
        Node otherBranch = (nextBranch == root.left) ? root.right : root.left;

        nearestNeighborSearch(nextBranch, target, depth + 1, bestNode, bestDist);

        if (Math.pow(target[cd] - root.location.getCoordinates()[cd], 2) < bestDist[0]) {
            nearestNeighborSearch(otherBranch, target, depth + 1, bestNode, bestDist);
        }
    }

    public Location findNearestNeighbor(Node root, double[] target) {
        Node[] bestNode = {null};
        double[] bestDist = {Double.MAX_VALUE};
        nearestNeighborSearch(root, target, 0, bestNode, bestDist);
        return bestNode[0] != null ? bestNode[0].location : null;
    }
}
