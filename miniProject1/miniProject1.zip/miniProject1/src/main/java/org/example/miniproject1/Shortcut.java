package org.example.miniproject1;

public class Shortcut {
    private String key;        // The shortcut key (e.g., "Ctrl + A")
    private String expansion;  // The text that the shortcut expands to (e.g., "Select All")

    // Default constructor
    public Shortcut() {
    }

    // Parameterized constructor
    public Shortcut(String key, String expansion) {
        this.key = key;
        this.expansion = expansion;
    }

    // Getter for key
    public String getKey() {
        return key;
    }

    // Setter for key
    public void setKey(String key) {
        this.key = key;
    }

    // Getter for expansion
    public String getExpansion() {
        return expansion;
    }

    // Setter for expansion
    public void setExpansion(String expansion) {
        this.expansion = expansion;
    }

    @Override
    public String toString() {
        return key + " -> " + expansion; // This will define how the Shortcut is represented in the ListView
    }
}
