package org.example.miniproject1.Model;

public class Node {
    Location location;
    Node left, right;

    public Node(Location location) {
        this.location = location;
        this.left = this.right = null;
    }
}
