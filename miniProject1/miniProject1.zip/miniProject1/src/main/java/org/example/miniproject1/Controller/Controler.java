package org.example.miniproject1.Controller;


import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class Controler {


    @FXML
    private VBox myvbox;

}
